import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PopGiftAddPage } from './pop-gift-add';

@NgModule({
  declarations: [
    PopGiftAddPage,
  ],
  imports: [
    IonicPageModule.forChild(PopGiftAddPage),
  ],
})
export class PopGiftAddPageModule {}
