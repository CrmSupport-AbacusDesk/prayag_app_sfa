import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ChangeStatusModelPage } from './change-status-model';

@NgModule({
  declarations: [
    ChangeStatusModelPage,
  ],
  imports: [
    IonicPageModule.forChild(ChangeStatusModelPage),
  ],
})
export class ChangeStatusModelPageModule {}
